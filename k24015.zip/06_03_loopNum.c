//
//  06_03_loopNum.c
//  prg1
//
//  Created by k24015kk on 2024/05/22.
//

#include <stdio.h>
int main(int argc, const char * argv[]){
    int i,n;
    printf("n? ");
    scanf("%d",&n);
    for(i=1 ; i<=n ; i++ ){
        printf("Hello,World\n");
    }
    return 0;
}

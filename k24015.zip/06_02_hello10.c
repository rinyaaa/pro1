//
//  06_02_hello10.c
//  prg1
//
//  Created by k24015kk on 2024/05/22.
//

#include <stdio.h>
int main(int argc, const char * argv[]){
    int i;
    for(i=1;i<=10;i++){
        printf("Hello,World\n");
    }
    return 0;
}

//
//  06_04_calcFor.c
//  prg1
//
//  Created by k24015kk on 2024/05/22.
//

#include <stdio.h>
int main(int argc, const char * argv[]){
    int i,sum;
    sum = 0;
    for(i=1;i<=10;i++){
        sum= sum + i;
        
    }
    printf("%d\n",sum);
    return 0;
}

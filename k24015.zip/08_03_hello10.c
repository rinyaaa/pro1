//
//  08_03_hello10.c
//  prg1
//
//  Created by k24015kk on 2024/06/01.
//

#include <stdio.h>
int main(int argc, const char * argv[]){
    int count;
    
    count = 1;
    while(count <= 10){
        printf("Hello,World!\n");
        count++;
    }
    
    return 0;
}

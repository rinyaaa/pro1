//
//  06_06_even1.c
//  prg1
//
//  Created by k24015kk on 2024/05/22.
//

#include <stdio.h>
int main(int argc, const char * argv[]){
    int i;
    for(i=0 ; i<=10 ; i+=2){
        printf("%d\n",i);
    }
    
    return 0;
}
